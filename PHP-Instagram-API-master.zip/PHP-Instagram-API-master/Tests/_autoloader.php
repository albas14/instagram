<?php

require( '_SplClassLoader.php' );

$loader = new SplClassLoader( 'Instagram', '../' );
$loader->register();